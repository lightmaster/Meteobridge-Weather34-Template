<style>
.webcam{
-webkit-border-radius:4px;	-moz-border-radius:4px;	-o-border-radius:4px;	-ms-border-radius:4px;border-radius:4px;border:solid RGBA(84, 85, 86, 1.00) 2px;width:275px;height:145px;margin:2px;}
</style>
<!-- HOMEWEATHER STATION TEMPLATE SIMPLE WEBCAM -add your url as shown below do NOT delete the class='webcam' !!! -->
<img src="https://icons.wunderground.com/webcamramdisk/d/j/djchids/1/current.jpg?version=<?php echo filemtime("https://icons.wunderground.com/webcamramdisk/d/j/djchids/1/current.jpg");?>" alt="weathercam" class="webcam">
</span>
